#include <iostream>
#include <fstream>
#include <sstream>
#include <cassert>
#include <string>
#include <list>
#include <functional>
#include <vector>
using namespace std;
#define buckets 50000
#define sequenceSize 6

#if defined(_MSC_VER)  &&  !defined(_DEBUG)
#include <iostream>
#include <windows.h>
#include <conio.h>

struct KeepWindowOpenUntilDismissed
{
	~KeepWindowOpenUntilDismissed()
	{
		DWORD pids[1];
		if (GetConsoleProcessList(pids, 1) == 1)
		{
			std::cout << "Press any key to continue . . . ";
			_getch();
		}
	}
} keepWindowOpenUntilDismissed;
#endif

class hashTable
{
public:
	hashTable()
	{
	}
	void insert(string data, int offset);
	bool get(string data, int &offset);
	list<pair<string, int>> table[buckets];
	
};

unsigned int hashFunction(const std::string &hash)
{
	std::hash<std::string> str_hash;
	unsigned int hashValue = str_hash(hash);
	unsigned int bucketNum = hashValue % buckets;
	return bucketNum;
}

void hashTable::insert(string data,int offset)
{
	int hashValue = hashFunction(data);
	table[hashValue].push_back(pair<string, int>(data, offset));
}

bool hashTable::get(string data, int& offset)
{
	int hashValue = hashFunction(data);
	list<pair<string, int>>::iterator it = table[hashValue].begin();
	while (it != table[hashValue].end())
	{
		if (it->first == data)
		{
			offset = it->second;
			return true;
		}
		it++;
	}
	
	offset = -1;
	return false;
}

void createDiff(istream& fold, istream& fnew, ostream& fdiff)
{
	bool match = false;
	string sequence; 
	int counter = 0;
	hashTable hashTable;
	string str, str2, diffString, dummy; // str and str2 are the old and new
	//diffString is what im writing output to fdiff
	//dummy is just to get the contents of the two old and new files.
	vector<char> add; //this is
	//gets the entire oldfile
	while (getline(fold, dummy))
	{
		str += dummy;
		if (!fold.eof())
		{
			str.push_back('\n');
		}
	}
	//gets the entire newfile
	while (getline(fnew, dummy))
	{
		str2 += dummy;
		if (!fnew.eof())
		{
			str2.push_back('\n');
		}
	}
	// breaks the entire old string into sequenceSize lengths and then
	// stores them in a hashtable with the original offsets.
	//for (int i = 0; i < str.size() - sequenceSize; i++)
	for (int i = 0; i < str.size() - sequenceSize; i++)
	{
		sequence = str.substr(i, sequenceSize);
		hashTable.insert(sequence, i);
		//insert auto generates the key for the hash table.
		//the substr auto handles if the size is less than the length of the string specified.
		//cerr << sequence << endl;
	}
	//this is to check if the string has appeared in the old file or not.
	int i = 0;
	//while (i < str2.size()-sequenceSize)
	while (i < str2.size())
	{
		string temp = str2.substr(i, sequenceSize);
		int hashValue = hashFunction(temp);
		int offset = 0;
		int maxLength = 0;
		int maxOffset = 0;
		if (hashTable.get(temp, offset)) //returns the original's offset
		{
			for (list<pair<string, int>>::iterator it = hashTable.table[hashValue].begin(); it != hashTable.table[hashValue].end(); it++)
			{
				int length = 0;
				int z = i;
				if (temp == it->first)
				{
					if (add.size() != 0)//check if theres previous things not added
					{
						diffString += "A" + to_string(add.size()) + ":";
						for (int k = 0; k < add.size(); k++)
						{
							diffString += add[k];
						}
					}
					add.clear();
					int tempOffset = it->second;
					//int tempOffset = offset;
					while (str2[z] == str[tempOffset])
					{
						length++;
						z++;
						tempOffset++;
						if (z >= str2.size() || tempOffset >= str.size())
						{
							break;
						}
					}
					if (length > maxLength)
					{
						maxLength = length;
						offset = it->second;
					}
					
					//diffString = diffString + "C" + to_string(maxLength) + "," + to_string(offset);
				}
			}
			diffString = diffString + "C" + to_string(maxLength) + "," + to_string(offset);
			i = i + maxLength;
		}
		else
		{
			add.push_back(str2[i]);
			i++;
		}
	}
	if (add.size() != 0)
	{
		diffString = diffString + "A" + to_string(add.size()) + ":";
		for (int z = 0; z < add.size(); z++)
		{
			diffString += add[z];
		}
		add.clear();
	}

	fdiff << diffString;
	cerr << "diffString:" << diffString << endl;
}

void runtest(string oldtext, string newtext);
bool runtest(string oldName, string newName, string diffName, string newName2);
int main()
{
	//ifstream infile("C:/Users/Ana/Documents/CS 32/testProj4/smallmart1.txt");
	//ifstream infile2("C:/Users/Ana/Documents/CS 32/testProj4/smallmart2.txt");
	//ofstream outfile("C:/Users/Ana/Documents/CS 32/testProj4/testing.txt");

	/*ifstream infile("C:/Users/Ana/Documents/CS 32/testProj4/greeneggs1.txt");
	ifstream infile2("C:/Users/Ana/Documents/CS 32/testProj4/greeneggs2.txt");
	ofstream outfile("C:/Users/Ana/Documents/CS 32/testProj4/testing.txt");*/

	/*ifstream infile("C:/Users/Ana/Documents/CS 32/testProj4/warandpeace1.txt");
	ifstream infile2("C:/Users/Ana/Documents/CS 32/testProj4/warandpeace2.txt");
	ofstream outfile("C:/Users/Ana/Documents/CS 32/testProj4/warandpeacetest.txt");*/
	/*if (!outfile)
	{
		cerr << "Error: Cannot create C:/Users/Ana/Documents/CS 32/testProj4/testing.txt" << endl;
		return 1;
	}
	if (!infile)
	{
		cerr << "Error: cannot open C:/Users/Ana/Documents/CS 32/testProj4/smallmart1.txt" << endl;
		return 1;
	}
	if (!infile2)
	{
		cerr << "Error: cannot open C:/Users/Ana/Documents/CS 32/testProj4/smallmart2.txt" << endl;
		return 1;
	}*/

	/*createDiff(infile, infile2, outfile); */

	runtest("abcdefghijklmn", "abxyzcdefghijklmn");
	runtest("There's a bathroom on the right.",
		"There's a bad moon on the rise.");
	runtest("ABCDEFGHIJBLAHPQRSTUVPQRSTUV",
		"XYABCDEFGHIJBLETCHPQRSTUVPQRSTQQELF");

	//assert(runtest("warandpeace1.txt", "warandpeace2.txt", "diff.txt", "testing.txt"));
	//assert(runtest("smallmart1.txt", "smallmart2.txt", "diff.txt", "testing.txt"));
	assert(runtest("strange1.txt", "strange2.txt", "diff.txt", "testing.txt"));
	//assert(runtest("greeneggs1.txt", "greeneggs2.txt", "diff.txt", "testing.txt"));

	//assert(runtest("C:/Users/Ana/Documents/CS 32/testProj4/warandpeace1.txt", "C:/Users/Ana/Documents/CS 32/testProj4/warandpeace2.txt", "C:/Users/Ana/Documents/CS 32/testProj4/diff.txt", "C:/Users/Ana/Documents/CS 32/testProj4/testing.txt"));
	//assert(runtest("C:/Users/Ana/Documents/CS 32/testProj4/smallmart1.txt", "C:/Users/Ana/Documents/CS 32/testProj4/smallmart2.txt", "C:/Users/Ana/Documents/CS 32/testProj4/diff.txt", "C:/Users/Ana/Documents/CS 32/testProj4/testing.txt"));
	//assert(runtest("C:/Users/Ana/Documents/CS 32/testProj4/strange1.txt", "C:/Users/Ana/Documents/CS 32/testProj4/strange2.txt", "C:/Users/Ana/Documents/CS 32/testProj4/diff.txt", "C:/Users/Ana/Documents/CS 32/testProj4/testing.txt"));
	cout << "everything passed" << endl;
	//assert(runtest("C:/Users/Ana/Documents/CS 32/testProj4/greeneggs1.txt", "C:/Users/Ana/Documents/CS 32/testProj4/greeneggs2.txt", "C:/Users/Ana/Documents/CS 32/testProj4/diff.txt", "C:/Users/Ana/Documents/CS 32/testProj4/testing.txt"));
}

//helper functions provided by smallberg
bool getInt(istream& inf, int& n)
{
	char ch;
	if (!inf.get(ch) || !isascii(ch) || !isdigit(ch))
		return false;
	inf.unget();
	inf >> n;
	return true;
}

bool getCommand(istream& inf, char& cmd, int& length, int& offset)
{
	if (!inf.get(cmd))
	{
		cmd = 'x';  // signals end of file
		return true;
	}
	char ch;
	switch (cmd)
	{
	case 'A':
		return getInt(inf, length) && inf.get(ch) && ch == ':';
	case 'C':
		return getInt(inf, length) && inf.get(ch) && ch == ',' && getInt(inf, offset);
	case '\r':
	case '\n':
		return true;
	}
	return false;
}
//this is to apply the patch 
bool applyDiff(istream& fold, istream& fdiff, ostream& fnew)
{
	int offset = 0;
	int length = 0;
	char next;
	char cmd = ' ';

	while (cmd != 'x')
	{
		if (!getCommand(fdiff, cmd, length, offset))
		{
			cerr << "you screwed up" << endl;
			return false;
		}
		if (cmd == 'A')
		{
			char c;
			for (int i = 0; i < length; i++)
			{
				fdiff.get(c);
				
				fnew << c;
			}
		}
		if (cmd == 'C')
		{
			fold.seekg(offset);

			for (int i = 0; i < length; i++)
			{
				fold.get(next);
				fnew << next;
			}
		}
		
	}
	return true;
}

void runtest(string oldtext, string newtext)
{
	istringstream foldile(oldtext);
	istringstream fnewile(newtext);
	ostringstream diffFile;
	createDiff(foldile, fnewile, diffFile);
	string result = diffFile.str();
	cout << "The diff file length is " << result.size()
		<< " and its text is " << endl;
	cout << result << endl;

	foldile.clear();   // clear the end of file condition
	foldile.seekg(0);  // reset back to beginning of the stream
	istringstream diffFile2(result);
	ostringstream fnewile2;
	assert(applyDiff(foldile, diffFile2, fnewile2));
	assert(newtext == fnewile2.str());
}

bool runtest(string oldName, string newName, string diffName, string newName2)
{
	if (diffName == oldName || diffName == newName ||
		newName2 == oldName || newName2 == diffName ||
		newName2 == newName)
	{
		cerr << "Files used for output must have names distinct from other files" << endl;
		return false;
	}
	ifstream oldFile(oldName, ios::binary);
	if (!oldFile)
	{
		cerr << "Cannot open " << oldName << endl;
		return false;
	}
	ifstream newFile(newName, ios::binary);
	if (!newFile)
	{
		cerr << "Cannot open " << newName << endl;
		return false;
	}
	ofstream diffFile(diffName, ios::binary);
	if (!diffFile)
	{
		cerr << "Cannot create " << diffName << endl;
		return false;
	}
	createDiff(oldFile, newFile, diffFile);
	diffFile.close();

	oldFile.clear();   // clear the end of file condition
	oldFile.seekg(0);  // reset back to beginning of the file
	ifstream diffFile2(diffName, ios::binary);
	if (!diffFile2)
	{
		cerr << "Cannot read the " << diffName << " that was just created!" << endl;
		return false;
	}
	ofstream newFile2(newName2, ios::binary);
	if (!newFile2)
	{
		cerr << "Cannot create " << newName2 << endl;
		return false;
	}
	assert(applyDiff(oldFile, diffFile2, newFile2));
	newFile2.close();

	newFile.clear();
	newFile.seekg(0);
	ifstream newFile3(newName2, ios::binary);
	if (!newFile)
	{
		cerr << "Cannot open " << newName2 << endl;
		return false;
	}
	if (!equal(istreambuf_iterator<char>(newFile), istreambuf_iterator<char>(),
		istreambuf_iterator<char>(newFile3), istreambuf_iterator<char>()))
	{

		cerr << newName2 << " is not identical to " << newName
			<< "; test FAILED" << endl;
		return false;
	}
	return true;
}
